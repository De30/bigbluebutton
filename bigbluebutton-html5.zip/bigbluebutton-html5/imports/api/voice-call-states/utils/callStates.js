const CallStateOptions = {
  CALL_STARTED: 'CALL_STARTED',
  IN_ECHO_TEST: 'IN_ECHO_TEST',
  IN_CONFERENCE: 'IN_CONFERENCE',
  CALL_ENDED: 'CALL_ENDED',
};

export default CallStateOptions;
