module.exports =
{
  setupTestFrameworkScriptFile: './jest.setup.js',
};
