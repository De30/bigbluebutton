exports.joinVideo = 'button[data-test="joinVideo"]';
exports.videoPreview = 'video[data-test="videoPreview"]';
exports.startSharingWebcam = 'button[data-test="startSharingWebcam"]';
exports.videoContainer = 'video[data-test="videoContainer"]';
exports.webcamConnectingStatus = '[data-test="webcamConnectingStatus"]';
exports.presentationFullscreenButton = '[data-test="presentationFullscreenButton"]';
