module.exports = exports =
{
  server: process.env.BBB_SERVER_URL,
  secret: process.env.BBB_SHARED_SECRET,
  welcome: '%3Cbr%3EWelcome+to+%3Cb%3E%25%25CONFNAME%25%25%3C%2Fb%3E%21',
  fullName: 'User1',
  moderatorPW: 'mp',
  attendeePW: 'ap',
};
