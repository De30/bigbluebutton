exports.firstUser = '[data-test="userListItemCurrent"]';
exports.userListItem = '[data-test="userListItem"]';
exports.setStatus = '[data-test="setstatus"]';
exports.away = '[data-test="away"]';
exports.applaud = '[data-test="applause"]';
exports.clearStatus = '[data-test="clearStatus"]';
exports.statusIcon = '[data-test="userAvatar"]';
