exports.manageUsers = '[data-test="manageUsers"]';
exports.createBreakoutRooms = '[data-test="createBreakoutRooms"]';
exports.inviteBreakoutRooms = '[data-test="inviteBreakoutRooms"]';
exports.randomlyAssign = '[data-test="randomlyAssign"]';
exports.modalConfirmButton = '[data-test="modalConfirmButton"]';
exports.breakoutRemainingTime = '[data-test="breakoutRemainingTime"]';
exports.breakoutRoomsItem = '[data-test="breakoutRoomsItem"]';
exports.breakoutJoin = '[data-test="breakoutJoin"]';
