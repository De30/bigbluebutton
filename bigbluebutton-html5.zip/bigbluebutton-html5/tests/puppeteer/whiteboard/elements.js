exports.whiteboard = '[data-test="whiteboard"]';
exports.tools = 'button[aria-label="Tools"]';
exports.pencil = 'button[aria-label="Pencil"]';
exports.rectangle = 'button[aria-label="Rectangle"]';
