

class Page {
  pressEnter() {
    browser.keys('Enter');
  }
}

module.exports = Page;
